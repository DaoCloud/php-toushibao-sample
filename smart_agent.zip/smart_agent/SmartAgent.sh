#!/bin/sh
#
# processname: SmartAgent
#
# description: Startup and shutdown script for SmartAgent
#
# Copyright: CloudWIse
# Author: Neeke.Gao  <neeke@php.net> <neeke.gao@yunzhihui.com>
#
PWDPATH=`dirname $0`

PROGNAME="SmartAgent"
DAEMONJAR=cloudwise-localmanager-1.0.0.jar
VERSION=1.0.2
LOGPATH=$PWDPATH/logs
CONFPATH=$PWDPATH/conf
LIBPATH=$PWDPATH/lib
PLUGINPATH=$PWDPATH/plugins
PIDFILE=$CONFPATH/.pid
LOCKFILE=$CONFPATH/.lock
DESC="SmartAgent daemon"
SCRIPTNAME=$PWDPATH/SmartAgent.sh

export shell_dir=`cd $PWDPATH && pwd`

export CLOUDWISE_simulation=/etc/cloudwise/
export CLASSPATH=$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/tools.jar:$shell_dir/conf:lib/$DAEMONJAR
export MAINCLASS=com.cloudwise.smartagent.main.LocalmanagerMain
JAVA_OPTS=" -Xmx30m -Xms30m "

(chmod -R 775 $PLUGINPATH/*/*.sh $LIBPATH) 2>/dev/null

parse_json(){
	echo $1 | sed 's/.*'$2':\([^,}]*\).*/\1/'
}

getDaeMonCount()
{
    if [ -e $PIDFILE ];then
        pid=`cat $PIDFILE`
        _count=`ps -p $pid|wc -l`
        echo ${_count}
    else
        echo 0
    fi
}

getSendProxyUrl()
{
    local __url
    __url=$1
    rawConfig=`cat $CONFPATH/sendProxy |tr "\n" " "|sed "s/ //g" |sed 's/"//g'`
    _SendProxy=$(parse_json $rawConfig 'SendProxy')

    if [ ${_SendProxy} != ${rawConfig} ]
    then
        echo ${_SendProxy}
    else
        echo ""
    fi
}

start()
{
	libcount=`ls -l $LIBPATH |wc -l`
	if [ $libcount -le 1 ]
	then
		echo "No libs build."
	else

        DaemonCount=$(getDaeMonCount)
        if [ $DaemonCount -gt 1 ]
        then
            echo "$PROGNAME is running."
        else
            if [ -e $LOCKFILE ];then
            echo "$PROGNAME is running."
            else

                echo "Starting $DESC: $PROGNAME"

                sendProxy=$(getSendProxyUrl)
                if [ -z "${sendProxy}" ]; then
                    echo " Please check the conf/sendProxy, and make sure contains the attribute 'SendProxy'. \n failed. "
                    exit
                fi

                _SendProxyStatus=`curl $sendProxy/status 2>/dev/null`
                if [ -z "${_SendProxyStatus}" ]; then
                    echo " Please check the url in conf/sendProxy, and make sure it's working.\n failed. "
                    exit
                fi

                nohup java $JAVA_OPTS -Dorg.apache.jasper.compiler.disablejsr199=true -Dagent.home=$shell_dir -cp $CLASSPATH $MAINCLASS > /dev/null &

                pid=$!

                echo $pid > $PIDFILE
                sleep 2

                DaemonCount=$(getDaeMonCount)
                if [ $DaemonCount -le 1 ]
                then
                   rm -rf $PIDFILE
                   echo "failed"
                else

                   touch $LOCKFILE
                   echo "OK"
                fi
            fi
        fi
	fi
}

stopAllplugins()
{
	pluginList=`ls $PLUGINPATH/*/*.sh`
    for pluginShell in `echo $pluginList`
    do
		echo "runing  $pluginShell  begin----"
		echo "--------"`$pluginShell stop 2>/dev/null`
		echo "runing  $pluginShell  end----\n\n"
    done
}

stop()
{
		if test -e $PIDFILE
		then
		   echo "Stopping $DESC: $PROGNAME"
		   if kill `cat $PIDFILE`
		   then
				  echo "OK"
		   else
				  echo "failed"
		   fi
		else
		   echo "No Server running"
		fi
		
		if test -e $LOCKFILE
		then
			rm -rf $LOCKFILE
		fi

		if test -e $PIDFILE
		then
			rm -rf $PIDFILE
		fi
}

stopall()
{
    stop
    stopAllplugins
}

restart()
{
    echo "Restarting $DESC: $PROGNAME"
    stop
    start
}

status()
{
    #curlResult=`curl http://127.0.0.1:27789/ 2>/dev/null`
    DaemonCount=$(getDaeMonCount)
    if [ $DaemonCount -gt 1 ]
    then
        jsonResult='{"AppName":"MyPlugin","Version":"MyVersion","States":"ok"}'
        echo $jsonResult |sed "s#MyPlugin#$PROGNAME#g;s#MyVersion#$VERSION#g"
    fi
}

case $1 in
    start)
	start && exit 0
        ;;
    stop)
        stop && exit 0
        ;;
    stopall)
        stopall && exit 0
        ;;
    restart)
        restart && exit 0
        ;;
    status)
        status
        ;;

    *)
        echo "Usage: $SCRIPTNAME {start|stop|stopall|restart|status}" >&2
        exit 1
        ;;
esac
exit 0
