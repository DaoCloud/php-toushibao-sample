#!/bin/sh
#
# processname: ServiceDiscover
#
# description: Startup and shutdown script for ServiceDiscover
#
# Author: Neeke.Gao  <neeke@php.net>
#
SCRIPTPATH=`dirname $0`
PWDPATH=`cd $SCRIPTPATH && pwd`

PROGNAME=lib/original-cloudwise-service-discover-0.2.jar
CONFIGNAME=conf/app.conf
DAEMON=$PWDPATH/$PROGNAME
CONFIG=$PWDPATH/$CONFIGNAME
LIB=$PWDPATH/lib
PIDFILE=$PWDPATH/bin/.pid
LOCKFILE=$PWDPATH/bin/.lock
BEATFILE=$PWDPATH/bin/heatbeat
DESC="SmartAgent MemcacheAgent daemon"
SCRIPTNAME=$PWDPATH/`basename $0`
uname=`uname`

export shell_dir=`cd $PWDPATH && pwd`

export CLASSPATH=$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/tools.jar:$shell_dir/lib/original-cloudwise-service-discover-0.2.jar:/$shell_dir/lib/cloudwise-service-discover-0.2.jar:$shell_dir/conf:
export MAINCLASS=com.cloudwise.smatagent.discover.main.ServiceDiscoverMain
JAVA_OPTS=" -Xmx30m -Xms30m "

(chmod -R 775 $PWDPATH/bin $PWDPATH/logs $PWDPATH/conf $PWDPATH/lib) 2>/dev/null
cd $PWDPATH

hostIdApi="http://127.0.0.1:27789/smartagent/getHostId"
hostKeyApi="http://127.0.0.1:27789/smartagent/getHostKey"
sendProxyApi="http://127.0.0.1:27789/smartagent/getSendProxy"

parse_json(){
	echo $1 | sed 's/.*'$2':\([^,}]*\).*/\1/'
}

strReplace()
{
    preStr="$1"
    postStr="$2"
    fileName="$3"
    if [ "${uname}" = "FreeBSD" ];then
        sed -I.bak "s#${1}#${2}#g" $3
    else
        sed -i "s#${1}#${2}#g" $3
    fi
}

processConf()
{
    __df_HostKey="MyHostKey"
    __df_HostId="MyHostId"
    __df_SendProxy="http://127.0.0.1:26789"

    appConf=`cat $CONFIG |tr "\n" " "|sed "s/ //g" |sed 's/"//g'`

    _hostId=$(parse_json $appConf 'HostId')
    _hostKey=$(parse_json $appConf 'HostKey')
    _sendProxy=$(parse_json $appConf 'SendProxy')

    if [ ${_hostId} != ${appConf} ] && [ ${_hostId} = ${__df_HostId} ]
    then
        _hostIdFromSA=`curl $hostIdApi 2>/dev/null`
        if [ ! -z "${_hostIdFromSA}" ]; then
            strReplace ${_hostId} ${_hostIdFromSA} $CONFIG
        fi
    fi

    if [ ${_hostKey} != ${appConf} ] && [ ${_hostKey} = ${__df_HostKey} ]
    then
        _hostKeyFromSA=`curl $hostKeyApi 2>/dev/null`
        if [ ! -z "${_hostKeyFromSA}" ]; then
            strReplace ${_hostKey} ${_hostKeyFromSA} $CONFIG
        fi
    fi

    if [ ${_sendProxy} != ${appConf} ] && [ ${_sendProxy} = ${__df_SendProxy} ]
    then
        _sendProxyFromSA=`curl $sendProxyApi 2>/dev/null`
        if [ ! -z "${_sendProxyFromSA}" ]; then
            strReplace ${_sendProxy} ${_sendProxyFromSA} $CONFIG
        fi
    fi
}

checkConf()
{
    __df_HostKey="MyHostKey"

    appConf=`cat $CONFIG |tr "\n" " "|sed "s/ //g" |sed 's/"//g'`

    _hostKey=$(parse_json $appConf 'HostKey')

    if [ ${_hostKey} != ${appConf} ] && [ ${_hostKey} = ${__df_HostKey} ]
    then
        echo "checkConf faild\n"
        echo "conf/app.conf  HostKey: is ${__df_HostKey}"
        echo "Please check SmartAgent!"
        exit 0
    fi
}

getDaeMonCount()
{
    if [ -e $PIDFILE ];then
        pid=`cat $PIDFILE`
        _count=`ps -p $pid|wc -l`
        echo ${_count}
    else
        echo 0
    fi
}

start()
{
    DaemonCount=$(getDaeMonCount)
    if [ $DaemonCount -gt 1 ]
    then
        echo "$PROGNAME is running."
    else
        if [ -e $LOCKFILE ];then
            echo "$PROGNAME is running."
        else
            if test -x $DAEMON
            then
                processConf
                checkConf

                echo "Starting $DESC: $PROGNAME"
                nohup java $JAVA_OPTS $CLOUDWISE_OPTS -Djava.library.path=$shell_dir/lib -Dagent.home=$shell_dir -cp $CLASSPATH $MAINCLASS  > /dev/null &

                pid=$!
                echo $pid > $PIDFILE
                sleep 2

                DaemonCount=$(getDaeMonCount)
                if [ $DaemonCount -le 1 ]
                then
                   rm -rf $PIDFILE
                   echo "failed"
                else

                   touch $LOCKFILE
                   echo "OK"
                fi
            else
                echo $PWDPATH
                echo "Couldn't find Server ($DAEMON)"
            fi
        fi
    fi
}

stop()
{
    if test -e $PIDFILE
    then
        echo "Stopping $DESC: $PROGNAME"
        if kill `cat $PIDFILE`
        then
            echo "OK"
        else
            echo "failed"
        fi
    else
        DaemonCount=$(getDaeMonCount)
        if [ $DaemonCount -gt 1 ]
        then
            echo "Stopping $DESC: $PROGNAME"
            (kill -9 $(ps -ef|grep $PROGNAME |awk '{print $2}')) 2> /dev/null
            echo "OK"
        else
            echo "No Server ($DAEMON) running"
        fi
    fi

    if test -e $LOCKFILE
        then
        rm -rf $LOCKFILE
    fi

    if test -e $PIDFILE
    then
        rm -rf $PIDFILE
    fi
}

restart()
{
    echo "Restarting $DESC: $PROGNAME"
    stop
    start
}

list()
{
    ps aux | grep $PROGNAME
}

status()
{
    if [ -e $BEATFILE ];then
        beatTime=`cat $BEATFILE`

        if [ $(($beatTime + 60)) -gt `date '+%s'` ]
        then
            propertiVision=`cat $PWDPATH/plugin.properties|grep version|sed "s#plugin.version=##g"`
            propertiName=`cat $PWDPATH/plugin.properties|grep name|sed "s#plugin.name=##g"`

            jsonResult='{"AppName":"MyPlugin","Version":"MyVersion","States":"ok","LastBeat":"MyLastBeat"}'

            echo $jsonResult |sed "s#MyPlugin#$propertiName#g;s#MyVersion#$propertiVision#g;s#MyLastBeat#$beatTime#g"
        fi
    fi
}

case $1 in
    start)
	start && exit 0
        ;;
    stop)
        stop && exit 0
        ;;
    restart)
        restart && exit 0
        ;;
    list)
        list
        ;;
    status)
        status
        ;;

    *)
        echo "Usage: $SCRIPTNAME {start|stop|restart|list|status}" >&2
        exit 1
        ;;
esac
exit 0
