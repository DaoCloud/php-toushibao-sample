#!/bin/sh
#
# processname: SendProxy
#
# description: Startup and shutdown script for SendProxy
#
# Author: Neeke.Gao  <neeke@php.net>
#
SCRIPTPATH=`dirname $0`
PWDPATH=`cd $SCRIPTPATH && pwd`

PROGNAME=bin/SendProxy

uname=`uname`
if [ "${uname}" = "FreeBSD" ];then
    PROGNAME=${PROGNAME}"BSD"
fi

CONFIGNAME=conf/app.conf
DAEMON=$PWDPATH/$PROGNAME
CONFIG=$PWDPATH/$CONFIGNAME
PIDFILE=$PWDPATH/bin/.pid
LOCKFILE=$PWDPATH/bin/.lock
DESC="SmartAgent SendProxy daemon"
SCRIPTNAME=$PWDPATH/`basename $0`

(chmod -R 775 $PWDPATH/bin $PWDPATH/logs $PWDPATH/conf) 2>/dev/null
cd $PWDPATH

if [ ! -f "${DAEMON}" ];then
    echo " Couldn't find Server ($DAEMON). "
    exit
fi

getDaeMonCount()
{
    if [ -e $PIDFILE ];then
        pid=`cat $PIDFILE`
        _count=`ps -p $pid|wc -l`
        echo ${_count}
    else
        echo 0
    fi
}

start()
{
    server_clock=`curl http://data.toushibao.com/server_clock 2>/dev/null`
    if [ -z "${server_clock}" ]; then
        echo " Please check the network, and make sure it is working. \n failed. "
        exit
    fi

    DaemonCount=$(getDaeMonCount)
    if [ $DaemonCount -gt 1 ]
    then
        echo "$PROGNAME is running."
    else
        if [ -e $LOCKFILE ];then
            echo "$PROGNAME is running."
        else
            if test -x $DAEMON
            then
                echo "Starting $DESC: $PROGNAME"
                nohup $DAEMON > /dev/null &

                pid=$!
                echo $pid > $PIDFILE
                sleep 2

                DaemonCount=$(getDaeMonCount)
                if [ $DaemonCount -le 1 ]
                then
                   rm -rf $PIDFILE
                   echo "failed"
                else
                   touch $LOCKFILE
                   echo "OK"
                fi
            else
                echo $PWDPATH
                echo "Couldn't find Server ($DAEMON)"
            fi
        fi
    fi
}

stop()
{
    if test -e $PIDFILE
    then
        echo "Stopping $DESC: $PROGNAME"
        if kill `cat $PIDFILE`
        then
            rm -rf $PIDFILE
            echo "OK"
        else
            echo "failed"
        fi
    else
        DaemonCount=$(getDaeMonCount)
        if [ $DaemonCount -gt 1 ]
        then
            echo "Stopping $DESC: $PROGNAME"
            (kill -9 $(ps -ef|grep $PROGNAME |awk '{print $2}')) 2> /dev/null
            echo "OK"
        else
            echo "No Server ($DAEMON) running"
        fi
    fi

    if test -e $LOCKFILE
        then
        rm -rf $LOCKFILE
    fi
}

restart()
{
    echo "Restarting $DESC: $PROGNAME"
    stop
    start
}

list()
{
    ps aux | grep $PROGNAME
}

status()
{
    echo `curl http://127.0.0.1:26789/status 2>/dev/null`
}

case $1 in
    start)
	start && exit 0
        ;;
    stop)
        stop && exit 0
        ;;
    restart)
        restart && exit 0
        ;;
    list)
        list
        ;;
    status)
        status
        ;;

    *)
        echo "Usage: $SCRIPTNAME {start|stop|restart|list|status}" >&2
        exit 1
        ;;
esac
exit 0
